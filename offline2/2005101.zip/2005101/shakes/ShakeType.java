package shakes;

public enum ShakeType {
    ChocolateShake,CoffeeShake,StrawberryShake,VanillaShake,ZeroShake
}
