package Ingredients;

public enum BaseIngredient {
    Milk,Sugar
}
