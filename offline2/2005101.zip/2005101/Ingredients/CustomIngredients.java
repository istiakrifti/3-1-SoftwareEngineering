package Ingredients;

public enum CustomIngredients {
    Almond_milk,Candy,Cookies
}
