package Ingredients;

public enum AdditionalIngredients {
    Chocolate_syrup,Chocolate_ice_cream,Coffee,Jello,Sugar_free_jello,Strawberry_syrup,Strawberry_ice_cream,Vanilla_flavoring,Sweetener
}
